$(document).ready(function () {

    // Banner Slider
    // Custom options for the carousel
    var args = {
        arrowRight: '.arrow-right',
        arrowLeft: '.arrow-left',
        speed: 700,
        slideDuration: 4000
    };
    // start BannerSlide
    $('.carousel').BannerSlide(args);

    // Owl carousel
    var owl = $('.owl-carousel');
    owl.owlCarousel({
        margin: 30,
        nav: true,
        loop: true,
        rtl: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 4
            }
        }
    })
    

    // Couter
    $(function () {
        function getCounterData(obj) {
            var days = parseInt($('.e-m-days', obj).text());
            var hours = parseInt($('.e-m-hours', obj).text());
            var minutes = parseInt($('.e-m-minutes', obj).text());
            var seconds = parseInt($('.e-m-seconds', obj).text());
            return seconds + (minutes * 60) + (hours * 3600) + (days * 3600 * 24);
        }

        function setCounterData(s, obj) {
            var days = Math.floor(s / (3600 * 24));
            var hours = Math.floor((s % (60 * 60 * 24)) / (3600));
            var minutes = Math.floor((s % (60 * 60)) / 60);
            var seconds = Math.floor(s % 60);

            console.log(days, hours, minutes, seconds);

            $('.e-m-days', obj).html(days);
            $('.e-m-hours', obj).html(hours);
            $('.e-m-minutes', obj).html(minutes);
            $('.e-m-seconds', obj).html(seconds);
        }

        var count = getCounterData($(".counter"));

        var timer = setInterval(function () {
            count--;
            if (count == 0) {
                clearInterval(timer);
                return;
            }
            setCounterData(count, $(".counter"));
        }, 1000);
    });

    // Counter

    $(function () {
        function getCounterData(obj) {
            var days = parseInt($('.e-m-days-2', obj).text());
            var hours = parseInt($('.e-m-hours-2', obj).text());
            var minutes = parseInt($('.e-m-minutes-2', obj).text());
            var seconds = parseInt($('.e-m-seconds-2', obj).text());
            return seconds + (minutes * 60) + (hours * 3600) + (days * 3600 * 24);
        }

        function setCounterData(s, obj) {
            var days = Math.floor(s / (3600 * 24));
            var hours = Math.floor((s % (60 * 60 * 24)) / (3600));
            var minutes = Math.floor((s % (60 * 60)) / 60);
            var seconds = Math.floor(s % 60);

            console.log(days, hours, minutes, seconds);

            $('.e-m-days-2', obj).html(days);
            $('.e-m-hours-2', obj).html(hours);
            $('.e-m-minutes-2', obj).html(minutes);
            $('.e-m-seconds-2', obj).html(seconds);
        }

        var count = getCounterData($(".counter-2"));

        var timer = setInterval(function () {
            count--;
            if (count == 0) {
                clearInterval(timer);
                return;
            }
            setCounterData(count, $(".counter-2"));
        }, 1000);
    });

    // Counter

    $(function () {
        function getCounterData(obj) {
            var days = parseInt($('.e-m-days-3', obj).text());
            var hours = parseInt($('.e-m-hours-3', obj).text());
            var minutes = parseInt($('.e-m-minutes-3', obj).text());
            var seconds = parseInt($('.e-m-seconds-3', obj).text());
            return seconds + (minutes * 60) + (hours * 3600) + (days * 3600 * 24);
        }

        function setCounterData(s, obj) {
            var days = Math.floor(s / (3600 * 24));
            var hours = Math.floor((s % (60 * 60 * 24)) / (3600));
            var minutes = Math.floor((s % (60 * 60)) / 60);
            var seconds = Math.floor(s % 60);

            console.log(days, hours, minutes, seconds);

            $('.e-m-days-3', obj).html(days);
            $('.e-m-hours-3', obj).html(hours);
            $('.e-m-minutes-3', obj).html(minutes);
            $('.e-m-seconds-3', obj).html(seconds);
        }

        var count = getCounterData($(".counter-3"));

        var timer = setInterval(function () {
            count--;
            if (count == 0) {
                clearInterval(timer);
                return;
            }
            setCounterData(count, $(".counter-3"));
        }, 1000);
    });

    // Counter

    $(function () {
        function getCounterData(obj) {
            var days = parseInt($('.e-m-days-4', obj).text());
            var hours = parseInt($('.e-m-hours-4', obj).text());
            var minutes = parseInt($('.e-m-minutes-4', obj).text());
            var seconds = parseInt($('.e-m-seconds-4', obj).text());
            return seconds + (minutes * 60) + (hours * 3600) + (days * 3600 * 24);
        }

        function setCounterData(s, obj) {
            var days = Math.floor(s / (3600 * 24));
            var hours = Math.floor((s % (60 * 60 * 24)) / (3600));
            var minutes = Math.floor((s % (60 * 60)) / 60);
            var seconds = Math.floor(s % 60);

            console.log(days, hours, minutes, seconds);

            $('.e-m-days-4', obj).html(days);
            $('.e-m-hours-4', obj).html(hours);
            $('.e-m-minutes-4', obj).html(minutes);
            $('.e-m-seconds-4', obj).html(seconds);
        }

        var count = getCounterData($(".counter-4"));

        var timer = setInterval(function () {
            count--;
            if (count == 0) {
                clearInterval(timer);
                return;
            }
            setCounterData(count, $(".counter-4"));
        }, 1000);
    });

    $(".footer h3").click(function () {
        $(this).toggleClass("openmenu");
    });

    $(".menu-icon-mobile").click(function () {
        $("body").addClass("asideOpen");
        $(".overlay").show();
    });

    $(".overlay").click(function () {
        $("body").removeClass("asideOpen");
        $(".overlay").hide();
        $(".cart-opner").removeClass("cartopen");
    });






    $("#site-search").focusin(function () {
        $(".suggestions").show();
    }).focusout(function () {
        $(".suggestions").hide();
    });


    $(".plus").click(function () {
        var item = $(this).closest(".plusminusunit").find("input");
        item.val(Number(item.val()) + 1);
    });
    $(".minus").click(function () {
        var item = $(this).closest(".plusminusunit").find("input");
        item.val(Number(item.val()) - 1);
    });

    $(".cart-opner").click(function () {
        $(this).addClass("cartopen");
        $(".overlay").show();
    });



});


$(document).ready(function () {
    // Show hide popover
    $(".dropdown-list").click(function () {
        $(this).toggleClass("megaopen");
    });
});
$(document).on("click", function (event) {
    var $trigger = $(".dropdown-list");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $(".dropdown-list.megaopen ").removeClass("megaopen");
    }
});


$(window).scroll(function(){
    if ($(window).scrollTop() >= 59) {
      $('.header').addClass('sticky');
     }
     else {
      $('.header').removeClass('sticky');
     }
  });


  $(".mobile-search-trigger").click(function () {
    $(".mobile-search").toggleClass("OpenMobileSearch");
});