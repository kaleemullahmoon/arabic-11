# Image-Slider-Using-only-HTML-CSS-
[![watch](https://i.postimg.cc/2ShmYd5G/maxresdefault.jpg)](https://www.youtube.com/watch?v=3MoRr5sudO0)
